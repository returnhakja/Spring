import React, { useState } from "react";
import axios from "axios";
import styles from "./AllPage.module.css";

function AllPage() {
    //전체출력
    const [data, setdata] = useState([]);
    const onAllDeptHandler = () => {
        axios
            .get("http://localhost:8080/jdbc/api/depts")

            .then((response) => setdata(response.data));
    };
    return (
        <div>
            <div className={styles.btn}>
                <h2>전체 테이블 출력</h2>
                <button onClick={onAllDeptHandler}>전체출력</button>
            </div>
            <div className={styles.data}>
                <table className={styles.table}>
                    {
                        <tr>
                            <td>DEPTNO</td>
                            <td>DNAME</td>
                            <td>LOC</td>
                        </tr>
                    }
                    {data.map((dept, index) => (
                        <tr key={index}>
                            <td>{dept.deptno}</td>
                            <td>{dept.dname}</td>
                            <td>{dept.loc}</td>
                        </tr>
                    ))}
                </table>
            </div>
        </div>
    );
}

export default AllPage;
