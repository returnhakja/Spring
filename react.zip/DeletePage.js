import React, { useState } from "react";
import axios from "axios";
import styles from "./AllPage.module.css";
function DeletePage() {
    //삭제
    const onDeleteHandler = () => {
        const locdelete = document.getElementById("locdelete");
        console.log(locdelete.value);
        const locdelete1 = locdelete.value;
        axios
            .delete("http://localhost:8080/jdbc/api/deptdelete/" + locdelete1)
            .then((response) => console.log(response.data));
    };

    //전체출력
    const [data, setdata] = useState([]);
    const onAllDeptHandler = () => {
        axios
            .get("http://localhost:8080/jdbc/api/depts")

            .then((response) => setdata(response.data));
    };

    return (
        <div>
            <h2> 테이블 삭제 </h2>
            <div className={styles.btn}>
                <input type="text" id="locdelete" placeholder="loc" />
                <button onClick={onDeleteHandler}>DELETE</button>
            </div>
            <hr />
            <div>
                <button onClick={onAllDeptHandler} className={styles.button}>
                    AllDept
                </button>
            </div>
            <div className={styles.data}>
                <table className={styles.table}>
                    <tr>
                        <td>DEPTNO</td>
                        <td>DNAME</td>
                        <td>LOC</td>
                    </tr>
                    {data.map((dept, index) => (
                        <tr key={index}>
                            <td>{dept.deptno}</td>
                            <td>{dept.dname}</td>
                            <td>{dept.loc}</td>
                        </tr>
                    ))}
                </table>
            </div>
        </div>
    );
}

export default DeletePage;
