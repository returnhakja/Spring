import React, { useState } from "react";
import axios from "axios";
import styles from "./AllPage.module.css";

function InsertPage() {
    const [data, setdata] = useState([]);
    const oninsertHandler = () => {
        const deptno2 = document.getElementById("deptno2");
        const dname2 = document.getElementById("dname2");
        const loc2 = document.getElementById("loc2");
        const deptno1 = deptno2.value;
        const dname1 = dname2.value;
        const loc1 = loc2.value;

        axios
            .post(
                "http://localhost:8080/jdbc/api/dept/" +
                    deptno1 +
                    "/" +
                    dname1 +
                    "/" +
                    loc1
            )
            .then((response) => console.log(response.data));
    };
    //전체출력
    const onAllDeptHandler = () => {
        axios
            .get("http://localhost:8080/jdbc/api/depts")

            .then((response) => setdata(response.data));
    };

    return (
        <div>
            <h2> 테이블 추가 </h2>
            <div className={styles.btn}>
                <input type="text" id="deptno2" placeholder="deptno" />
                <input type="text" id="dname2" placeholder="dname" />
                <input type="text" id="loc2" placeholder="loc" />

                <button onClick={oninsertHandler} id="btn">
                    insert
                </button>
            </div>

            <button onClick={onAllDeptHandler} className={styles.button}>
                AllDept
            </button>

            <div className={styles.data}>
                <table className={styles.table}>
                    <tr>
                        <td>DEPTNO</td>
                        <td>DNAME</td>
                        <td>LOC</td>
                    </tr>
                    {data.map((dept, index) => (
                        <tr key={index}>
                            <td>{dept.deptno}</td>
                            <td>{dept.dname}</td>
                            <td>{dept.loc}</td>
                        </tr>
                    ))}
                </table>
            </div>
        </div>
    );
}

export default InsertPage;
