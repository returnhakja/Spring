import axios from "axios";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import styles from "./Mini.module.css";

function Mini() {
    //전체출력
    // const [data, setdata] = useState([]);
    // const onAllDeptHandler = () => {
    //     axios
    //         .get("http://localhost:8080/jdbc/api/depts")

    //         .then((response) => setdata(response.data));
    // };

    //삽입

    // const oninsertHandler = () => {
    //     const deptno2 = document.getElementById("deptno2");
    //     const dname2 = document.getElementById("dname2");
    //     const loc2 = document.getElementById("loc2");
    //     const deptno1 = deptno2.value;
    //     const dname1 = dname2.value;
    //     const loc1 = loc2.value;

    //     axios
    //         .post(
    //             "http://localhost:8080/jdbc/api/dept/" +
    //                 deptno1 +
    //                 "/" +
    //                 dname1 +
    //                 "/" +
    //                 loc1
    //         )
    //         .then((response) => setdata(response.data));
    // };

    //삭제
    // const onDeleteHandler = () => {
    //     const locdelete = document.getElementById("locdelete");
    //     console.log(locdelete.value);
    //     const locdelete1 = locdelete.value;
    //     axios
    //         .delete("http://localhost:8080/jdbc/api/deptdelete/" + locdelete1)
    //         .then((response) => console.log(response.data));
    // };

    //업데이트
    // const onUpdateHandler = () => {
    //     const locUpdate = document.getElementById("Uloc");
    //     const Udeptno = document.getElementById("Udeptno");
    //     const Udname = document.getElementById("Udname");

    //     console.log(locUpdate.value);
    //     console.log(Udeptno.value);
    //     console.log(Udname.value);
    //     const update1 = locUpdate.value;
    //     const udeptno = Udeptno.value;
    //     const udname = Udname.value;
    //     axios
    //         .put(
    //             "http://localhost:8080/jdbc/api/update/" +
    //                 update1 +
    //                 "/" +
    //                 udeptno +
    //                 "/" +
    //                 udname
    //         )
    //         .then((response) => console.log(response.data));
    // };

    return (
        <div className={styles.alldiv}>
            <div>
                <h2>전체 테이블 출력</h2>
                <Link to={"/alldept"}>
                    {/* <button onClick={onAllDeptHandler}>AllDept</button> */}
                    <p>테이블 출력하러 가기</p>
                </Link>
            </div>
            <div>
                {/* {data.map((dept, index) => (
                     <tr key={index}>
                         <td>{dept.deptno}</td>
                         <td>{dept.dname}</td>
                         <td>{dept.loc}</td>
                     </tr>
                 ))}  */}
            </div>
            <br />
            <hr />
            <div>
                <h2> 테이블 추가 </h2>
                {/* <input type="text" id="deptno2" placeholder="deptno" />
                <input type="text" id="dname2" placeholder="dname" />
                <input type="text" id="loc2" placeholder="loc" /> */}
                <Link to={"/deptinsert"}>
                    {/* <button onClick={oninsertHandler}>insert</button> */}
                    <p> 테이블 추가로 이동하기 </p>
                </Link>
            </div>
            <br />
            <hr />
            <div>
                <h2> 테이블 삭제 </h2>
                {/* <input type="text" id="locdelete" placeholder="loc" />
                <button onClick={onDeleteHandler}>DELETE</button> */}
                <Link to={"/deptdelete"}>
                    {" "}
                    <p> loc로 테이블 삭제하러 가기</p>{" "}
                </Link>
            </div>
            <hr />
            <div>
                <h2> 테이블 수정 </h2>
                {/* <input type="text" id="Uloc" placeholder="Updateloc" />
                <input type="text" id="Udeptno" placeholder="deptno" />
                <input type="text" id="Udname" placeholder="dname" />
                <button onClick={onUpdateHandler}>Update</button> */}
                <Link to={"/deptupdate"}>
                    {" "}
                    <p> loc수정하러 가기</p>{" "}
                </Link>
            </div>
        </div>
    );
}

export default Mini;
