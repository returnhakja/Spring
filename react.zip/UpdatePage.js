import React, { useState } from "react";
import axios from "axios";
import styles from "./AllPage.module.css";

function UpdatePage() {
    const [data, setdata] = useState([]);
    const onUpdateHandler = () => {
        const locUpdate = document.getElementById("Uloc");
        const Udeptno = document.getElementById("Udeptno");
        const Udname = document.getElementById("Udname");

        console.log(locUpdate.value);
        console.log(Udeptno.value);
        console.log(Udname.value);
        const update1 = locUpdate.value;
        const udeptno = Udeptno.value;
        const udname = Udname.value;
        axios
            .put(
                "http://localhost:8080/jdbc/api/update/" +
                    update1 +
                    "/" +
                    udeptno +
                    "/" +
                    udname
            )
            .then((response) => console.log(response.data));
    };
    //전체출력
    const onAllDeptHandler = () => {
        axios
            .get("http://localhost:8080/jdbc/api/depts")

            .then((response) => setdata(response.data));
    };
    return (
        <div>
            <h2> 테이블 수정 </h2>
            <div className={styles.btn}>
                <input type="text" id="Uloc" placeholder="Updateloc" />
                <input type="text" id="Udeptno" placeholder="deptno" />
                <input type="text" id="Udname" placeholder="dname" />
                <button onClick={onUpdateHandler}>Update</button>
            </div>
            <div>
                <button onClick={onAllDeptHandler} className={styles.button}>
                    AllDept
                </button>
            </div>
            <div className={styles.data}>
                <table className={styles.table}>
                    <tr>
                        <td>DEPTNO</td>
                        <td>DNAME</td>
                        <td>LOC</td>
                    </tr>
                    {data.map((dept, index) => (
                        <tr key={index}>
                            <td>{dept.deptno}</td>
                            <td>{dept.dname}</td>
                            <td>{dept.loc}</td>
                        </tr>
                    ))}
                </table>
            </div>
        </div>
    );
}

export default UpdatePage;
