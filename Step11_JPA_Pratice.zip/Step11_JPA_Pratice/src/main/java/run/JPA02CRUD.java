package run;



public class JPA02CRUD {
	

	
	
}
